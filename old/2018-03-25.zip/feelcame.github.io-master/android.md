# Android software
__________________
## Офис
_проги для работы с текстом_

* [MS Office](#test)
  * Word
  * Exel
  * PowerPoint
* [Notepad++](/test)
* [ABYY FineReader](index)

## Мультимедиа
`Программы для прослушивания музыки, просмотра видео и т.д.`
* [PotPlayer](http://tegos.ru)
* ![](/img/logo.jpg)[AIMP](http://aimp.ru)


