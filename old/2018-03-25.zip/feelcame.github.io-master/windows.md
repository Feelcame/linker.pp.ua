## Windows soft

[Офис](#офис) | [Мультимедиа](#мультимедиа) | [Интернет](#интернет) | [Система](#система) | [Безопасность](#безопасность) | [CD/DVD](#cddvd-образы-загрузочные-флешки) | [Драйверы](#драйверы)  
Здеся представлены  ознакомительные ссылки на  программы, которые  я использую сам.  

### Офис
* Microsoft Office - [nnm](#nnm)
* Notepad++ - [оф.сайт](#npp) - nnm - rutracker
* 

### Мультимедиа
* PotPlayer - оф.сайт - rutracker
* AIMP - оф.сайт
* AIMP Remote Control Plugin - оф.сайт
* Audacity - диктофон - оф.сайт - nnm - rutracker
* FastStone Capture - скриншотер

### Интернет
* Браузеры
  * Chrome
  * Firefox
  * Расширения к ним
* Download Master
* uTorrent 2.2.1
* NetWorx
* TeamViever

### Общение
* Telegram
* Skype
* Mozilla Thunderbird

### Система
* Total Commander
* Uninstall Tool
* Your Uninstaller
* System Explorer
* Start8
* 

### Безопасность
* Dr.Web CureIt
* AdwCleaner

### CD/DVD, образы, загрузочные флешки
* Rufus
* UltraISO
* RusLive dvd
* 

### Драйверы
* Asus 1015bx
  * видео
  сеть
  тачпад
* с++
* DirectX
